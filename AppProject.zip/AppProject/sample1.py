from flask import Flask, render_template, jsonify, request, make_response, send_from_directory
import os
from flask_sqlalchemy import SQLAlchemy
import pymysql


appname = "IOT - sample1"
app = Flask(appname)

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://as:sa@ec2-18-192-245-67.eu-central-1.compute.amazonaws.com:6033/app_db'
db = SQLAlchemy(app)

class JJ_form(db.Model):
    __tablename__ = 'JJ'
    ID = db.Column(db.Integer, primary_key = True)
    presenza = db.Column(db.Integer)
    posizione = db.Column(db.String(20))
    nome = db.Column(db.String(20))
    cognome = db.Column(db.String(20))

@app.route("/prova")
def proviamo():
    try:
        all_data = JJ_form.query.filter_by(ID=123456).first()
        jj_text = '<ul>'
        #for sock in all_data:
            #jj_text += '<li>' + sock.nome + ', ' + sock.posizione + '</li>'
        jj_text = '<li>' +all_data.posizione + '</li>'
        jj_text += '</ul>'
        return jj_text
    except Exception as e:
        # e holds description of the error
        error_text = "<p>The error:<br>" + str(e) + "</p>"
        hed = '<h1>Something is broken.</h1>'
        return hed + error_text

@app.route("/user-interface", methods=['GET'])
def webHTML():
    return render_template('index.html')

@app.route('/get-new-address/<code>', methods=['GET'])
def getNewAddress(code):
    if len(str(code)) != 6 :
        errorResponse = make_response("Code not valid", 500)
        errorResponse.headers.add('Access-Control-Allow-Origin', '*')
        return errorResponse

    indirizzo = JJ_form.query.filter_by(ID=code).first()
    response = jsonify({
        'address': indirizzo.posizione, 
    })

    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    if path != "" and os.path.exists(app.static_folder + '/' + path):
        return send_from_directory(app.static_folder, path)
    else:
        return send_from_directory(app.static_folder, 'index.html')


if __name__ == '__main__':
    app.run(use_reloader=True, port=5000, threaded=True)
