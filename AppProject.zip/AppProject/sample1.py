from flask import Flask, render_template, jsonify, request, make_response, send_from_directory
import os
from flask_sqlalchemy import SQLAlchemy
from geoalchemy2 import Geometry
import pymysql


appname = "IOT - sample1"
app = Flask(appname)

app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://as:sa@ec2-3-69-25-163.eu-central-1.compute.amazonaws.com:6033/app_db'
db = SQLAlchemy(app)

class JJ_form(db.Model):
    __tablename__ = 'JJ'
    presenza = db.Column(db.Integer)
    nome = db.Column(db.String(20))
    cognome = db.Column(db.String(20))
    MAC = db.Column(db.String(17), primary_key = True)
    #posizione = db.Column(Geometry(geometry_type='POINT', srid=4326))
    indirizzo = db.Column(db.String(30))
    chatID = db.Column(db.String(20))
    latitudine = db.Column(db.Float)
    longitudine = db.Column(db.Float)

@app.route("/prova")
def proviamo():
    try:
        all_data = JJ_form.query.filter_by(MAC="77:77:77:77:77:77").first()
        jj_text = '<ul>'
        #for sock in all_data:
            #jj_text += '<li>' + sock.nome + ', ' + sock.posizione + '</li>'
        jj_text = '<li>' +all_data.posizione + '</li>'
        jj_text += '</ul>'
        return jj_text
    except Exception as e:
        # e holds description of the error
        error_text = "<p>The error:<br>" + str(e) + "</p>"
        hed = '<h1>Something is broken.</h1>'
        return hed + error_text

@app.route("/user-interface", methods=['GET'])
def webHTML():
    return render_template('index.html')

@app.route('/get-new-address/<code>', methods=['GET'])
def getNewAddress(code):
    if len(str(code)) != 12 :
        errorResponse = make_response("Code not valid", 500)
        errorResponse.headers.add('Access-Control-Allow-Origin', '*')
        return errorResponse
    code_mac=''
    i=0
    for i in range(len(str(code))) :
        if i%2 == 0 and i!=0:
            code_mac += ':' + str(code)[i]
        else : 
            code_mac += str(code)[i]
    print(code_mac)
    indirizzo = JJ_form.query.filter_by(MAC=code_mac).first()
    response = jsonify({
        'address': indirizzo.indirizzo, 
    })

    response.headers.add('Access-Control-Allow-Origin', '*')
    return response

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    if path != "" and os.path.exists(app.static_folder + '/' + path):
        return send_from_directory(app.static_folder, path)
    else:
        return send_from_directory(app.static_folder, 'index.html')


if __name__ == '__main__':
    app.run(use_reloader=True, port=5000, threaded=True) #aggiungere host
